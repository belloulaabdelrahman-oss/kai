class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg-base)] text-white">
          <h2>Something went wrong in POS.</h2>
        </div>
      );
    }
    return this.props.children;
  }
}

const DEFAULT_PRODUCTS = [
    { id: 1, name: 'Premium Wireless Headphones', price: 199.99, category: 'Electronics', stock: 45, image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format&fit=crop&q=60' },
    { id: 2, name: 'Mechanical Keyboard', price: 129.50, category: 'Accessories', stock: 20, image: 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=500&auto=format&fit=crop&q=60' },
    { id: 3, name: 'Ergonomic Mouse', price: 59.99, category: 'Accessories', stock: 35, image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=500&auto=format&fit=crop&q=60' },
    { id: 4, name: 'USB-C Hub', price: 45.00, category: 'Accessories', stock: 100, image: 'https://images.unsplash.com/photo-1512316609839-ce289d3eba0a?w=500&auto=format&fit=crop&q=60' },
    { id: 5, name: '4K Monitor', price: 349.99, category: 'Electronics', stock: 12, image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=500&auto=format&fit=crop&q=60' },
    { id: 6, name: 'Laptop Stand', price: 35.00, category: 'Accessories', stock: 60, image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=500&auto=format&fit=crop&q=60' },
];

function POSApp() {
    const [cart, setCart] = React.useState([]);
    const [searchQuery, setSearchQuery] = React.useState('');
    const [activeCategory, setActiveCategory] = React.useState('All');
    const [products, setProducts] = React.useState([]);
    const [categories, setCategories] = React.useState([]);
    const [showSuccessModal, setShowSuccessModal] = React.useState(false);
    const [lastInvoiceId, setLastInvoiceId] = React.useState('');
    
    const [customers, setCustomers] = React.useState([]);
    const [showCustomerModal, setShowCustomerModal] = React.useState(false);
    const [isCreatingCustomer, setIsCreatingCustomer] = React.useState(false);
    const [customerSearch, setCustomerSearch] = React.useState('');
    const [isScanning, setIsScanning] = React.useState(false);

    React.useEffect(() => {
        const storedCustomers = localStorage.getItem('nexpos_customers');
        if (storedCustomers) {
            setCustomers(JSON.parse(storedCustomers));
        } else {
            setCustomers([
                { id: 1, name: 'Alice Smith', email: 'alice@example.com', phone: '+1 234-567-8900', totalSpent: 1250.00, lastVisit: '2026-06-15' },
                { id: 2, name: 'Bob Jones', email: 'bob@example.com', phone: '+1 987-654-3210', totalSpent: 450.50, lastVisit: '2026-06-18' },
            ]);
        }

        const storedProducts = localStorage.getItem('nexpos_products');
        setProducts(storedProducts ? JSON.parse(storedProducts) : DEFAULT_PRODUCTS);

        const storedCats = localStorage.getItem('nexpos_categories');
        const defaultCats = [ { id: 1, name: 'Electronics' }, { id: 2, name: 'Accessories' }, { id: 3, name: 'Software' } ];
        setCategories(storedCats ? JSON.parse(storedCats) : defaultCats);
    }, []);

    const filteredProducts = products.filter(p => {
        const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
        const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    const addToCart = (product) => {
        setCart(prev => {
            const existing = prev.find(item => item.id === product.id);
            if (existing) {
                return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
            }
            return [...prev, { ...product, quantity: 1 }];
        });
    };

    const updateQuantity = (id, delta) => {
        setCart(prev => prev.map(item => {
            if (item.id === id) {
                const newQuantity = Math.max(1, item.quantity + delta);
                return { ...item, quantity: newQuantity };
            }
            return item;
        }));
    };

    const removeItem = (id) => {
        setCart(prev => prev.filter(item => item.id !== id));
    };

    const handleScan = () => {
        setIsScanning(true);
        setTimeout(() => {
            if (products.length > 0) {
                // Simulate finding a random product via scan
                const randomProduct = products[Math.floor(Math.random() * products.length)];
                addToCart(randomProduct);
                setSearchQuery(''); // clear search to show the scan effect implicitly via cart update
            }
            setIsScanning(false);
        }, 1500);
    };

    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const settings = getStoreSettings();
    const taxRate = settings.taxRate !== undefined && settings.taxRate !== null ? Number(settings.taxRate) : 8;
    const tax = subtotal * (taxRate / 100);
    const total = subtotal + tax;

    const initiateCheckout = () => {
        setShowCustomerModal(true);
        setIsCreatingCustomer(false);
        setCustomerSearch('');
    };

    const finalizeCheckout = (customerData) => {
        const customerName = typeof customerData === 'string' ? customerData : customerData.name;
        
        if (typeof customerData === 'object') {
            // Read directly from localStorage to ensure we have the most recent data (especially after instant creation)
            const currentCustomers = JSON.parse(localStorage.getItem('nexpos_customers') || '[]');
            const updatedCustomers = currentCustomers.map(c => 
                c.id === customerData.id 
                ? { ...c, totalSpent: (c.totalSpent || 0) + total, lastVisit: new Date().toISOString().split('T')[0] } 
                : c
            );
            setCustomers(updatedCustomers);
            localStorage.setItem('nexpos_customers', JSON.stringify(updatedCustomers));
        }

        const newInvoice = {
            id: `INV-${Date.now().toString().slice(-6)}`,
            date: new Date().toISOString(),
            items: [...cart],
            subtotal,
            tax,
            total,
            customer: customerName
        };

        const stored = localStorage.getItem('nexpos_invoices');
        const invoices = stored ? JSON.parse(stored) : [];
        invoices.unshift(newInvoice);
        localStorage.setItem('nexpos_invoices', JSON.stringify(invoices));
        
        setLastInvoiceId(newInvoice.id);
        setCart([]);
        setShowCustomerModal(false);
        setShowSuccessModal(true);
    };

    const handleCreateCustomer = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const newCustomer = {
            id: Date.now(),
            name: formData.get('name'),
            email: formData.get('email') || 'N/A',
            phone: formData.get('phone') || 'N/A',
            totalSpent: 0,
            lastVisit: new Date().toISOString().split('T')[0]
        };
        const newCustomersList = [newCustomer, ...customers];
        setCustomers(newCustomersList);
        localStorage.setItem('nexpos_customers', JSON.stringify(newCustomersList));
        finalizeCheckout(newCustomer);
    };

    return (
        <div className="flex h-screen bg-[var(--bg-base)] relative" data-name="pos-app" data-file="pos-app.js">
            <Sidebar currentPath="/pos.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Point of Sale" />
                
                <main className="flex-1 flex overflow-hidden">
                    {/* Products Section */}
                    <div className="flex-1 flex flex-col p-6 overflow-hidden">
                        <div className="flex gap-4 mb-6">
                            <div className="relative flex-1">
                                <div className="icon-search absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"></div>
                                <input 
                                    type="text" 
                                    placeholder="Scan barcode or search products..." 
                                    className="input-field pl-10"
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                />
                            </div>
                            <button className="btn-secondary" onClick={handleScan} title="Scan Product Barcode">
                                <div className="icon-scan text-xl"></div>
                            </button>
                        </div>

                        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
                            {['All', ...categories.map(c => c.name)].map(cat => (
                                <button 
                                    key={cat}
                                    onClick={() => setActiveCategory(cat)}
                                    className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
                                        activeCategory === cat 
                                        ? 'bg-[var(--primary)] text-white' 
                                        : 'bg-[var(--bg-panel)] text-[var(--text-muted)] hover:bg-[var(--bg-panel-hover)]'
                                    }`}
                                >
                                    {cat}
                                </button>
                            ))}
                        </div>

                        <div className="flex-1 overflow-y-auto pr-2">
                            <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                                {filteredProducts.map(product => (
                                    <div 
                                        key={product.id} 
                                        onClick={() => addToCart(product)}
                                        className="bg-[var(--bg-panel)] border border-[var(--border-color)] rounded-xl overflow-hidden cursor-pointer hover:border-[var(--primary)] transition-colors group"
                                    >
                                        <div className="h-32 bg-[var(--bg-panel-hover)] relative">
                                            <img src={product.image} alt={product.name} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                                            <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white px-2 py-1 rounded text-xs">
                                                {product.stock} in stock
                                            </div>
                                        </div>
                                        <div className="p-4">
                                            <h3 className="font-medium text-sm text-[var(--text-main)] mb-1 truncate">{product.name}</h3>
                                            <p className="text-[var(--primary)] font-bold">{formatCurrency(product.price)}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Cart Section */}
                    <div className="w-96 bg-[var(--bg-panel)] border-l border-[var(--border-color)] flex flex-col">
                        <div className="p-4 border-b border-[var(--border-color)] flex justify-between items-center">
                            <h2 className="font-bold text-lg">Current Order</h2>
                            <button className="text-[var(--text-muted)] hover:text-[var(--danger)] transition-colors" onClick={() => setCart([])}>
                                <div className="icon-trash-2 text-xl"></div>
                            </button>
                        </div>

                        <div className="flex-1 overflow-y-auto p-4 space-y-4">
                            {cart.length === 0 ? (
                                <div className="h-full flex flex-col items-center justify-center text-[var(--text-muted)]">
                                    <div className="icon-shopping-cart text-5xl mb-4 opacity-50"></div>
                                    <p>Cart is empty</p>
                                </div>
                            ) : (
                                cart.map(item => (
                                    <div key={item.id} className="flex gap-3 bg-[var(--bg-base)] p-3 rounded-lg border border-[var(--border-color)]">
                                        <img src={item.image} alt={item.name} className="w-16 h-16 rounded object-cover" />
                                        <div className="flex-1 flex flex-col justify-between">
                                            <div className="flex justify-between items-start">
                                                <h4 className="text-sm font-medium line-clamp-1">{item.name}</h4>
                                                <button onClick={() => removeItem(item.id)} className="text-[var(--text-muted)] hover:text-[var(--danger)]">
                                                    <div className="icon-x text-sm"></div>
                                                </button>
                                            </div>
                                            <div className="flex justify-between items-center mt-2">
                                                <p className="font-bold text-[var(--primary)]">{formatCurrency(item.price * item.quantity)}</p>
                                                <div className="flex items-center gap-3 bg-[var(--bg-panel)] rounded-lg p-1 border border-[var(--border-color)]">
                                                    <button onClick={() => updateQuantity(item.id, -1)} className="text-[var(--text-muted)] hover:text-white">
                                                        <div className="icon-minus text-sm"></div>
                                                    </button>
                                                    <span className="text-sm font-medium w-4 text-center">{item.quantity}</span>
                                                    <button onClick={() => updateQuantity(item.id, 1)} className="text-[var(--text-muted)] hover:text-white">
                                                        <div className="icon-plus text-sm"></div>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>

                        <div className="p-6 bg-[var(--bg-base)] border-t border-[var(--border-color)]">
                            <div className="space-y-3 mb-6 text-sm">
                                <div className="flex justify-between text-[var(--text-muted)]">
                                    <span>Subtotal</span>
                                    <span>{formatCurrency(subtotal)}</span>
                                </div>
                                <div className="flex justify-between text-[var(--text-muted)]">
                                    <span>Tax ({taxRate}%)</span>
                                    <span>{formatCurrency(tax)}</span>
                                </div>
                                <div className="flex justify-between text-lg font-bold text-[var(--text-main)] pt-3 border-t border-[var(--border-color)]">
                                    <span>Total</span>
                                    <span>{formatCurrency(total)}</span>
                                </div>
                            </div>
                            <button 
                                onClick={initiateCheckout}
                                className={`w-full py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition-colors ${
                                    cart.length === 0 
                                    ? 'bg-[var(--bg-panel-hover)] text-[var(--text-muted)] cursor-not-allowed' 
                                    : 'bg-[var(--primary)] text-white hover:bg-[var(--primary-hover)]'
                                }`}
                                disabled={cart.length === 0}
                            >
                                <div className="icon-credit-card"></div>
                                Checkout
                            </button>
                        </div>
                    </div>
                </main>

                {showCustomerModal && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                        <div className="bg-[var(--bg-panel)] border border-[var(--border-color)] rounded-xl w-full max-w-md max-h-[80vh] flex flex-col overflow-hidden">
                            <div className="p-4 border-b border-[var(--border-color)] flex justify-between items-center bg-[var(--bg-panel)] z-10">
                                <h2 className="text-lg font-bold">{isCreatingCustomer ? 'Create New Customer' : 'Select Customer'}</h2>
                                <button onClick={() => setShowCustomerModal(false)} className="text-[var(--text-muted)] hover:text-white">
                                    <div className="icon-x text-xl"></div>
                                </button>
                            </div>

                            {!isCreatingCustomer ? (
                                <div className="flex-1 flex flex-col overflow-hidden">
                                    <div className="p-4 border-b border-[var(--border-color)] space-y-3 bg-[var(--bg-base)]">
                                        <button 
                                            onClick={() => finalizeCheckout('Walk-in Customer')}
                                            className="w-full py-2 bg-[var(--bg-panel)] border border-[var(--border-color)] text-[var(--text-main)] rounded-lg font-medium hover:bg-[var(--bg-panel-hover)] transition-colors flex justify-center items-center gap-2"
                                        >
                                            <div className="icon-user"></div>
                                            Continue as Walk-in Customer
                                        </button>
                                        <div className="flex gap-2">
                                            <div className="relative flex-1">
                                                <div className="icon-search absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"></div>
                                                <input 
                                                    type="text" 
                                                    placeholder="Search customers..." 
                                                    className="input-field pl-10 w-full"
                                                    value={customerSearch}
                                                    onChange={(e) => setCustomerSearch(e.target.value)}
                                                />
                                            </div>
                                            <button 
                                                onClick={() => setIsCreatingCustomer(true)}
                                                className="btn-primary"
                                                title="Add New Customer"
                                            >
                                                <div className="icon-plus"></div>
                                            </button>
                                        </div>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-2">
                                        {customers.filter(c => c.name.toLowerCase().includes(customerSearch.toLowerCase()) || (c.phone && c.phone.includes(customerSearch))).map(c => (
                                            <div 
                                                key={c.id} 
                                                onClick={() => finalizeCheckout(c)}
                                                className="p-3 hover:bg-[var(--bg-panel-hover)] rounded-lg cursor-pointer flex justify-between items-center transition-colors border-b border-[var(--border-color)] last:border-0"
                                            >
                                                <div>
                                                    <p className="font-medium text-[var(--text-main)]">{c.name}</p>
                                                    <p className="text-xs text-[var(--text-muted)]">{c.phone} • {c.email}</p>
                                                </div>
                                                <div className="icon-chevron-right text-[var(--text-muted)]"></div>
                                            </div>
                                        ))}
                                        {customers.filter(c => c.name.toLowerCase().includes(customerSearch.toLowerCase()) || (c.phone && c.phone.includes(customerSearch))).length === 0 && (
                                            <div className="text-center py-6 text-[var(--text-muted)]">
                                                No customers found.
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ) : (
                                <form onSubmit={handleCreateCustomer} className="p-6 space-y-4 overflow-y-auto">
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Full Name</label>
                                        <input type="text" name="name" className="input-field" placeholder="e.g. John Doe" required />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Email Address</label>
                                        <input type="email" name="email" className="input-field" placeholder="john@example.com" />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Phone Number</label>
                                        <input type="tel" name="phone" className="input-field" placeholder="+1 234-567-8900" />
                                    </div>
                                    <div className="pt-4 flex gap-3">
                                        <button type="submit" className="btn-primary flex-1 justify-center">Save & Checkout</button>
                                        <button type="button" onClick={() => setIsCreatingCustomer(false)} className="btn-secondary flex-1 justify-center">Back</button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                )}

                {isScanning && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
                        <div className="bg-[var(--bg-panel)] border border-[var(--border-color)] rounded-xl p-8 max-w-sm w-full text-center">
                            <div className="w-16 h-16 bg-[var(--primary)]/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                                <div className="icon-scan text-3xl text-[var(--primary)]"></div>
                            </div>
                            <h2 className="text-xl font-bold mb-2">Scanning Barcode...</h2>
                            <p className="text-[var(--text-muted)]">Please hold the barcode in front of the scanner.</p>
                            <button className="mt-6 text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors text-sm" onClick={() => setIsScanning(false)}>
                                Cancel
                            </button>
                        </div>
                    </div>
                )}

                {showSuccessModal && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
                        <div className="bg-[var(--bg-panel)] border border-[var(--border-color)] rounded-xl p-8 max-w-sm w-full text-center">
                            <div className="w-16 h-16 bg-[var(--success)]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                                <div className="icon-circle-check text-3xl text-[var(--success)]"></div>
                            </div>
                            <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
                            <p className="text-[var(--text-muted)] mb-6">Invoice <span className="font-medium text-[var(--text-main)]">{lastInvoiceId}</span> has been generated.</p>
                            
                            <div className="flex flex-col gap-3">
                                <button className="btn-primary justify-center" onClick={() => window.location.href='/invoices.html'}>
                                    View Invoices
                                </button>
                                <button className="bg-[var(--bg-panel-hover)] text-[var(--text-main)] px-4 py-2 rounded-lg hover:bg-[var(--border-color)] font-medium transition-colors" onClick={() => setShowSuccessModal(false)}>
                                    Start New Sale
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <POSApp />
  </ErrorBoundary>
);