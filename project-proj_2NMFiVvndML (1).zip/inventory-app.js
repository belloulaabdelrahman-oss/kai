function InventoryApp() {
    const inventory = [
        { id: 1, name: 'Premium Wireless Headphones', sku: 'WH-001', stock: 45, status: 'In Stock', location: 'Warehouse A' },
        { id: 2, name: 'Mechanical Keyboard', sku: 'KB-002', stock: 5, status: 'Low Stock', location: 'Store Front' },
        { id: 3, name: 'USB-C Cable', sku: 'CBL-001', stock: 0, status: 'Out of Stock', location: 'Warehouse B' },
    ];

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/inventory.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Inventory" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-7xl mx-auto">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold">Inventory Control</h2>
                            <button className="btn-primary">
                                <div className="icon-arrow-up-down"></div> Stock Transfer
                            </button>
                        </div>
                        <div className="card overflow-x-auto">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="border-b border-[var(--border-color)] text-[var(--text-muted)]">
                                        <th className="pb-3 font-medium">Product</th>
                                        <th className="pb-3 font-medium">SKU</th>
                                        <th className="pb-3 font-medium">Location</th>
                                        <th className="pb-3 font-medium">Quantity</th>
                                        <th className="pb-3 font-medium">Status</th>
                                        <th className="pb-3 font-medium text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {inventory.map(item => (
                                        <tr key={item.id} className="border-b border-[var(--border-color)] hover:bg-[var(--bg-panel-hover)]">
                                            <td className="py-4 font-medium">{item.name}</td>
                                            <td className="py-4 text-[var(--text-muted)]">{item.sku}</td>
                                            <td className="py-4">{item.location}</td>
                                            <td className="py-4 font-bold">{item.stock}</td>
                                            <td className="py-4">
                                                <span className={`px-2 py-1 rounded text-xs font-medium ${item.stock > 10 ? 'bg-[var(--success)]/20 text-[var(--success)]' : item.stock > 0 ? 'bg-[var(--warning)]/20 text-[var(--warning)]' : 'bg-[var(--danger)]/20 text-[var(--danger)]'}`}>
                                                    {item.status}
                                                </span>
                                            </td>
                                            <td className="py-4 text-right">
                                                <button className="text-[var(--primary)] hover:underline text-sm font-medium">Adjust</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<InventoryApp />);