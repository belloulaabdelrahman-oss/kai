function ProductsApp() {
    const defaultProducts = [
        { id: 1, name: 'Premium Wireless Headphones', sku: 'WH-001', price: 199.99, category: 'Electronics', stock: 45 },
        { id: 2, name: 'Mechanical Keyboard', sku: 'KB-002', price: 129.50, category: 'Accessories', stock: 20 },
        { id: 3, name: 'Ergonomic Mouse', sku: 'MS-003', price: 59.99, category: 'Accessories', stock: 35 },
    ];

    const [products, setProducts] = React.useState(() => {
        const stored = localStorage.getItem('nexpos_products');
        return stored ? JSON.parse(stored) : defaultProducts;
    });

    React.useEffect(() => {
        localStorage.setItem('nexpos_products', JSON.stringify(products));
    }, [products]);

    const handleDelete = (id) => {
        if (confirm('Are you sure you want to delete this product?')) {
            setProducts(products.filter(p => p.id !== id));
        }
    };

    const handleEdit = (id) => {
        window.location.href = `/add-product.html?id=${id}`;
    };

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/products.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Products" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-7xl mx-auto">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold">Product Management</h2>
                            <button className="btn-primary" onClick={() => window.location.href='/add-product.html'}>
                                <div className="icon-plus"></div> Add Product
                            </button>
                        </div>
                        <div className="card overflow-x-auto">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="border-b border-[var(--border-color)] text-[var(--text-muted)]">
                                        <th className="pb-3 font-medium">Name</th>
                                        <th className="pb-3 font-medium">SKU</th>
                                        <th className="pb-3 font-medium">Category</th>
                                        <th className="pb-3 font-medium">Price</th>
                                        <th className="pb-3 font-medium">Stock</th>
                                        <th className="pb-3 font-medium text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {products.map(p => (
                                        <tr key={p.id} className="border-b border-[var(--border-color)] hover:bg-[var(--bg-panel-hover)] transition-colors">
                                            <td className="py-4 font-medium">{p.name}</td>
                                            <td className="py-4 text-[var(--text-muted)]">{p.sku}</td>
                                            <td className="py-4"><span className="bg-[var(--bg-base)] px-2 py-1 rounded text-xs">{p.category}</span></td>
                                            <td className="py-4">{formatCurrency(p.price)}</td>
                                            <td className="py-4">{p.stock}</td>
                                            <td className="py-4 text-right space-x-2">
                                                <button onClick={() => handleEdit(p.id)} className="text-[var(--text-muted)] hover:text-[var(--primary)] transition-colors"><div className="icon-pencil"></div></button>
                                                <button onClick={() => handleDelete(p.id)} className="text-[var(--text-muted)] hover:text-[var(--danger)] transition-colors"><div className="icon-trash"></div></button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ProductsApp />);