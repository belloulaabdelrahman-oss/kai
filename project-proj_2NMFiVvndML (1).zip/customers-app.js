function CustomersApp() {
    const defaultCustomers = [
        { id: 1, name: 'Alice Smith', email: 'alice@example.com', phone: '+1 234-567-8900', totalSpent: 1250.00, lastVisit: '2026-06-15' },
        { id: 2, name: 'Bob Jones', email: 'bob@example.com', phone: '+1 987-654-3210', totalSpent: 450.50, lastVisit: '2026-06-18' },
    ];

    const [customers, setCustomers] = React.useState(() => {
        const stored = localStorage.getItem('nexpos_customers');
        return stored ? JSON.parse(stored) : defaultCustomers;
    });

    React.useEffect(() => {
        localStorage.setItem('nexpos_customers', JSON.stringify(customers));
    }, [customers]);

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/customers.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Customers" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-7xl mx-auto">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold">Customer Directory</h2>
                            <button className="btn-primary" onClick={() => window.location.href='/add-customer.html'}>
                                <div className="icon-user-plus"></div> Add Customer
                            </button>
                        </div>
                        <div className="card overflow-x-auto">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="border-b border-[var(--border-color)] text-[var(--text-muted)]">
                                        <th className="pb-3 font-medium">Name</th>
                                        <th className="pb-3 font-medium">Contact</th>
                                        <th className="pb-3 font-medium">Total Spent</th>
                                        <th className="pb-3 font-medium">Last Visit</th>
                                        <th className="pb-3 font-medium text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {customers.map(c => (
                                        <tr key={c.id} className="border-b border-[var(--border-color)] hover:bg-[var(--bg-panel-hover)]">
                                            <td className="py-4 font-medium">{c.name}</td>
                                            <td className="py-4">
                                                <div className="text-sm">{c.email}</div>
                                                <div className="text-xs text-[var(--text-muted)]">{c.phone}</div>
                                            </td>
                                            <td className="py-4 font-bold text-[var(--primary)]">{formatCurrency(c.totalSpent)}</td>
                                            <td className="py-4 text-[var(--text-muted)]">{c.lastVisit}</td>
                                            <td className="py-4 text-right">
                                                <button className="text-[var(--text-muted)] hover:text-[var(--primary)]"><div className="icon-external-link"></div></button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<CustomersApp />);