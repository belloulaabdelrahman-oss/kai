function InvoicesApp() {
    const [invoices, setInvoices] = React.useState(() => {
        const stored = localStorage.getItem('nexpos_invoices');
        return stored ? JSON.parse(stored) : [];
    });

    const [selectedInvoice, setSelectedInvoice] = React.useState(null);

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/invoices.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Invoices" />
                <main className="flex-1 overflow-y-auto p-6 relative">
                    <div className="max-w-7xl mx-auto">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold">Transaction History</h2>
                        </div>
                        <div className="card overflow-x-auto">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="border-b border-[var(--border-color)] text-[var(--text-muted)]">
                                        <th className="pb-3 font-medium">Invoice ID</th>
                                        <th className="pb-3 font-medium">Date</th>
                                        <th className="pb-3 font-medium">Customer</th>
                                        <th className="pb-3 font-medium">Items</th>
                                        <th className="pb-3 font-medium">Total</th>
                                        <th className="pb-3 font-medium text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {invoices.map(inv => (
                                        <tr key={inv.id} className="border-b border-[var(--border-color)] hover:bg-[var(--bg-panel-hover)] transition-colors">
                                            <td className="py-4 font-medium">{inv.id}</td>
                                            <td className="py-4 text-[var(--text-muted)]">{new Date(inv.date).toLocaleDateString()} {new Date(inv.date).toLocaleTimeString()}</td>
                                            <td className="py-4">{inv.customer}</td>
                                            <td className="py-4">{inv.items.length} items</td>
                                            <td className="py-4 font-bold text-[var(--primary)]">{formatCurrency(inv.total)}</td>
                                            <td className="py-4 text-right">
                                                <button onClick={() => setSelectedInvoice(inv)} className="text-[var(--text-muted)] hover:text-[var(--text-main)] bg-[var(--bg-panel-hover)] px-3 py-1 rounded">View</button>
                                            </td>
                                        </tr>
                                    ))}
                                    {invoices.length === 0 && (
                                        <tr>
                                            <td colSpan="6" className="py-8 text-center text-[var(--text-muted)]">No invoices found. Process a checkout in the POS to generate one.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {selectedInvoice && (
                        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
                            <div className="bg-[var(--bg-panel)] border border-[var(--border-color)] rounded-xl w-full max-w-lg flex flex-col max-h-full">
                                <div className="p-4 border-b border-[var(--border-color)] flex justify-between items-center">
                                    <h3 className="font-bold text-lg">Invoice Details</h3>
                                    <button onClick={() => setSelectedInvoice(null)} className="text-[var(--text-muted)] hover:text-white">
                                        <div className="icon-x text-xl"></div>
                                    </button>
                                </div>
                                <div className="p-6 overflow-y-auto">
                                    <div className="flex justify-between mb-6">
                                        <div>
                                            <p className="text-[var(--text-muted)] text-sm mb-1">Invoice ID</p>
                                            <p className="font-medium">{selectedInvoice.id}</p>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-[var(--text-muted)] text-sm mb-1">Date</p>
                                            <p className="font-medium">{new Date(selectedInvoice.date).toLocaleString()}</p>
                                        </div>
                                    </div>
                                    <div className="mb-6">
                                        <p className="text-[var(--text-muted)] text-sm mb-1">Customer</p>
                                        <p className="font-medium">{selectedInvoice.customer}</p>
                                    </div>
                                    <table className="w-full mb-6">
                                        <thead>
                                            <tr className="border-b border-[var(--border-color)] text-[var(--text-muted)] text-sm">
                                                <th className="pb-2 text-left font-medium">Item</th>
                                                <th className="pb-2 text-center font-medium">Qty</th>
                                                <th className="pb-2 text-right font-medium">Price</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {selectedInvoice.items.map((item, idx) => (
                                                <tr key={idx} className="border-b border-[var(--border-color)]/50">
                                                    <td className="py-3 text-sm">{item.name}</td>
                                                    <td className="py-3 text-sm text-center">{item.quantity}</td>
                                                    <td className="py-3 text-sm text-right">{formatCurrency(item.price * item.quantity)}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                    <div className="space-y-2 text-sm ml-auto w-48">
                                        <div className="flex justify-between text-[var(--text-muted)]">
                                            <span>Subtotal</span>
                                            <span>{formatCurrency(selectedInvoice.subtotal)}</span>
                                        </div>
                                        <div className="flex justify-between text-[var(--text-muted)]">
                                            <span>Tax</span>
                                            <span>{formatCurrency(selectedInvoice.tax)}</span>
                                        </div>
                                        <div className="flex justify-between font-bold text-lg pt-2 border-t border-[var(--border-color)]">
                                            <span>Total</span>
                                            <span>{formatCurrency(selectedInvoice.total)}</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="p-4 border-t border-[var(--border-color)] flex justify-end gap-3">
                                    <button className="btn-primary" onClick={() => window.print()}>
                                        <div className="icon-printer"></div> Print
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<InvoicesApp />);