function CategoriesApp() {
    const defaultCategories = [
        { id: 1, name: 'Electronics' },
        { id: 2, name: 'Accessories' },
        { id: 3, name: 'Software' }
    ];

    const [categories, setCategories] = React.useState(() => {
        const stored = localStorage.getItem('nexpos_categories');
        return stored ? JSON.parse(stored) : defaultCategories;
    });

    React.useEffect(() => {
        localStorage.setItem('nexpos_categories', JSON.stringify(categories));
    }, [categories]);

    const handleDelete = (id) => {
        if (confirm('Are you sure you want to delete this category?')) {
            setCategories(categories.filter(c => c.id !== id));
        }
    };

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/categories.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Categories" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-4xl mx-auto">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold">Product Categories</h2>
                            <button className="btn-primary" onClick={() => window.location.href='/add-category.html'}>
                                <div className="icon-plus"></div> Add Category
                            </button>
                        </div>
                        <div className="card overflow-x-auto">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="border-b border-[var(--border-color)] text-[var(--text-muted)]">
                                        <th className="pb-3 font-medium">ID</th>
                                        <th className="pb-3 font-medium">Name</th>
                                        <th className="pb-3 font-medium text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {categories.map(c => (
                                        <tr key={c.id} className="border-b border-[var(--border-color)] hover:bg-[var(--bg-panel-hover)] transition-colors">
                                            <td className="py-4 text-[var(--text-muted)]">#{c.id}</td>
                                            <td className="py-4 font-medium">{c.name}</td>
                                            <td className="py-4 text-right space-x-2">
                                                <button onClick={() => handleDelete(c.id)} className="text-[var(--text-muted)] hover:text-[var(--danger)] transition-colors"><div className="icon-trash"></div></button>
                                            </td>
                                        </tr>
                                    ))}
                                    {categories.length === 0 && (
                                        <tr>
                                            <td colSpan="3" className="py-8 text-center text-[var(--text-muted)]">No categories found.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<CategoriesApp />);