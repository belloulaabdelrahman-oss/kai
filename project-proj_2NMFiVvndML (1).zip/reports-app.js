function ReportsApp() {
    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/reports.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Reports" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-7xl mx-auto">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold">Analytics & Reports</h2>
                            <button className="btn-primary">
                                <div className="icon-download"></div> Export Data
                            </button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="card h-64 flex items-center justify-center text-[var(--text-muted)] flex-col gap-3">
                                <div className="icon-chart-bar text-4xl"></div>
                                <p>Sales Data Chart Will Render Here</p>
                            </div>
                            <div className="card h-64 flex items-center justify-center text-[var(--text-muted)] flex-col gap-3">
                                <div className="icon-chart-pie text-4xl"></div>
                                <p>Product Categories Chart Will Render Here</p>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ReportsApp />);