function AddCategoryApp() {
    const handleSave = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        
        const newCat = {
            id: Date.now(),
            name: formData.get('name'),
        };

        const stored = localStorage.getItem('nexpos_categories');
        const defaultCategories = [
            { id: 1, name: 'Electronics' },
            { id: 2, name: 'Accessories' },
            { id: 3, name: 'Software' }
        ];
        const categories = stored ? JSON.parse(stored) : defaultCategories;
        
        categories.push(newCat);
        localStorage.setItem('nexpos_categories', JSON.stringify(categories));
        window.location.href = '/categories.html';
    };

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/categories.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Add New Category" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-2xl mx-auto">
                        <div className="flex items-center gap-4 mb-6">
                            <button onClick={() => window.location.href='/categories.html'} className="text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors">
                                <div className="icon-arrow-left text-2xl"></div>
                            </button>
                            <h2 className="text-2xl font-bold">Create Category</h2>
                        </div>
                        
                        <form onSubmit={handleSave} className="space-y-6">
                            <div className="card space-y-4">
                                <h3 className="font-semibold text-lg border-b border-[var(--border-color)] pb-3">Category Details</h3>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Category Name</label>
                                    <input type="text" name="name" className="input-field" placeholder="e.g. Peripherals" required />
                                </div>
                            </div>

                            <div className="flex gap-3">
                                <button type="submit" className="btn-primary flex-1 justify-center">Save Category</button>
                                <button type="button" onClick={() => window.location.href='/categories.html'} className="btn-secondary flex-1 justify-center">Cancel</button>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AddCategoryApp />);