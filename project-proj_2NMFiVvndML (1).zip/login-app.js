function LoginApp() {
    const [isLoading, setIsLoading] = React.useState(false);
    const [error, setError] = React.useState('');

    const handleLogin = (e) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');

        const formData = new FormData(e.target);
        const email = formData.get('email');
        const password = formData.get('password');

        // Simulate authentication
        setTimeout(() => {
            if (email && password.length >= 6) {
                window.location.href = '/index.html';
            } else {
                setError('Invalid email or password. Password must be at least 6 characters.');
                setIsLoading(false);
            }
        }, 1000);
    };

    return (
        <div className="min-h-screen flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[var(--bg-panel)] border border-[var(--border-color)] rounded-2xl p-8 shadow-2xl">
                <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[var(--primary)]/10 text-[var(--primary)] mb-4">
                        <div className="icon-hexagon text-3xl"></div>
                    </div>
                    <h1 className="text-2xl font-bold text-[var(--text-main)] mb-2">Welcome Back</h1>
                    <p className="text-[var(--text-muted)]">Sign in to your NexPOS account</p>
                </div>

                {error && (
                    <div className="bg-[var(--danger)]/10 border border-[var(--danger)]/20 text-[var(--danger)] px-4 py-3 rounded-lg mb-6 text-sm flex items-start gap-2">
                        <div className="icon-circle-alert mt-0.5"></div>
                        <p>{error}</p>
                    </div>
                )}

                <form onSubmit={handleLogin} className="space-y-5">
                    <div>
                        <label className="block text-sm font-medium text-[var(--text-main)] mb-1.5">Email Address</label>
                        <div className="relative">
                            <div className="icon-mail absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"></div>
                            <input 
                                type="email" 
                                name="email" 
                                className="input-field pl-10" 
                                placeholder="admin@nexpos.com" 
                                required 
                                defaultValue="admin@nexpos.com"
                            />
                        </div>
                    </div>
                    
                    <div>
                        <div className="flex justify-between items-center mb-1.5">
                            <label className="block text-sm font-medium text-[var(--text-main)]">Password</label>
                            <a href="#" className="text-xs text-[var(--primary)] hover:underline">Forgot password?</a>
                        </div>
                        <div className="relative">
                            <div className="icon-lock absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"></div>
                            <input 
                                type="password" 
                                name="password" 
                                className="input-field pl-10" 
                                placeholder="••••••••" 
                                required 
                                defaultValue="password123"
                            />
                        </div>
                    </div>

                    <div className="flex items-center">
                        <input type="checkbox" id="remember" className="rounded bg-[var(--bg-base)] border-[var(--border-color)] text-[var(--primary)] focus:ring-[var(--primary)] w-4 h-4" />
                        <label htmlFor="remember" className="ml-2 text-sm text-[var(--text-muted)]">Remember me for 30 days</label>
                    </div>

                    <button type="submit" className="btn-primary mt-6" disabled={isLoading}>
                        {isLoading ? (
                            <div className="icon-loader animate-spin"></div>
                        ) : (
                            <>Sign In <div className="icon-arrow-right"></div></>
                        )}
                    </button>
                </form>
                
                <div className="mt-8 text-center text-sm text-[var(--text-muted)]">
                    Don't have an account? <a href="#" className="text-[var(--primary)] hover:underline">Contact Support</a>
                </div>
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<LoginApp />);