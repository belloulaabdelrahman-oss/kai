function AddProductApp() {
    const urlParams = new URLSearchParams(window.location.search);
    const editId = urlParams.get('id');

    const [product, setProduct] = React.useState(() => {
        if (editId) {
            const storedProducts = localStorage.getItem('nexpos_products');
            if (storedProducts) {
                const products = JSON.parse(storedProducts);
                return products.find(p => p.id === parseInt(editId)) || {};
            }
        }
        return {};
    });

    const [imagePreview, setImagePreview] = React.useState(product.image || null);
    const [categories, setCategories] = React.useState([]);
    const [isScanning, setIsScanning] = React.useState(false);
    const fileInputRef = React.useRef(null);

    React.useEffect(() => {
        const storedCats = localStorage.getItem('nexpos_categories');
        const defaultCats = [ { id: 1, name: 'Electronics' }, { id: 2, name: 'Accessories' }, { id: 3, name: 'Software' } ];
        setCategories(storedCats ? JSON.parse(storedCats) : defaultCats);
    }, []);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        const file = e.dataTransfer.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setImagePreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleScan = () => {
        setIsScanning(true);
        setTimeout(() => {
            const randomSku = 'SCN-' + Math.floor(100000 + Math.random() * 900000);
            const skuInput = document.querySelector('input[name="sku"]');
            if(skuInput) {
                skuInput.value = randomSku;
            }
            setIsScanning(false);
        }, 1500);
    };

    const handleSave = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        
        const newProduct = {
            id: Date.now(),
            name: formData.get('name'),
            price: parseFloat(formData.get('price')),
            sku: formData.get('sku') || `PRD-${Date.now().toString().slice(-4)}`,
            stock: parseInt(formData.get('stock')) || 0,
            category: formData.get('category'),
            image: imagePreview || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format&fit=crop&q=60'
        };

        const stored = localStorage.getItem('nexpos_products');
        const defaultProducts = [
            { id: 1, name: 'Premium Wireless Headphones', sku: 'WH-001', price: 199.99, category: 'Electronics', stock: 45 },
            { id: 2, name: 'Mechanical Keyboard', sku: 'KB-002', price: 129.50, category: 'Accessories', stock: 20 },
            { id: 3, name: 'Ergonomic Mouse', sku: 'MS-003', price: 59.99, category: 'Accessories', stock: 35 },
        ];
        const products = stored ? JSON.parse(stored) : defaultProducts;
        
        if (editId) {
            const index = products.findIndex(p => p.id === parseInt(editId));
            if (index > -1) {
                products[index] = { ...products[index], ...newProduct, id: parseInt(editId) };
            }
        } else {
            products.unshift(newProduct);
        }

        localStorage.setItem('nexpos_products', JSON.stringify(products));
        window.location.href = '/products.html';
    };

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/products.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Add New Product" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-4xl mx-auto">
                        <div className="flex items-center gap-4 mb-6">
                            <button onClick={() => window.location.href='/products.html'} className="text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors">
                                <div className="icon-arrow-left text-2xl"></div>
                            </button>
                            <h2 className="text-2xl font-bold">{new URLSearchParams(window.location.search).has('id') ? 'Edit Product' : 'Create Product'}</h2>
                        </div>
                        
                        <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            <div className="lg:col-span-2 space-y-6">
                                <div className="card space-y-4">
                                    <h3 className="font-semibold text-lg border-b border-[var(--border-color)] pb-3">Basic Information</h3>
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Product Name</label>
                                        <input type="text" name="name" defaultValue={product.name} className="input-field" placeholder="e.g. Premium Wireless Headphones" required />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Description</label>
                                        <textarea name="description" defaultValue={product.description} className="input-field h-32 resize-none" placeholder="Product details..."></textarea>
                                    </div>
                                </div>

                                <div className="card space-y-4">
                                    <h3 className="font-semibold text-lg border-b border-[var(--border-color)] pb-3">Media</h3>
                                    <input 
                                        type="file" 
                                        ref={fileInputRef} 
                                        onChange={handleImageChange} 
                                        accept="image/*" 
                                        className="hidden" 
                                    />
                                    <div 
                                        onClick={() => fileInputRef.current?.click()}
                                        onDragOver={(e) => e.preventDefault()}
                                        onDrop={handleDrop}
                                        className="border-2 border-dashed border-[var(--border-color)] rounded-xl p-8 flex flex-col items-center justify-center text-center hover:border-[var(--primary)] transition-colors cursor-pointer bg-[var(--bg-base)] relative overflow-hidden min-h-[200px]"
                                    >
                                        {imagePreview ? (
                                            <div className="absolute inset-0 w-full h-full group">
                                                <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                                                    <span className="text-white font-medium flex items-center gap-2">
                                                        <div className="icon-image"></div> Change Image
                                                    </span>
                                                </div>
                                            </div>
                                        ) : (
                                            <>
                                                <div className="icon-image text-4xl text-[var(--text-muted)] mb-3"></div>
                                                <p className="font-medium mb-1">Drop your image here, or browse</p>
                                                <p className="text-sm text-[var(--text-muted)]">Supports JPG, PNG and WEBP</p>
                                            </>
                                        )}
                                    </div>
                                </div>

                                <div className="card space-y-4">
                                    <h3 className="font-semibold text-lg border-b border-[var(--border-color)] pb-3">Pricing & Inventory</h3>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium mb-1">Price ({getCurrencySymbol()})</label>
                                            <input type="number" step="0.01" name="price" defaultValue={product.price} className="input-field" placeholder="0.00" required />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium mb-1">Cost ({getCurrencySymbol()})</label>
                                            <input type="number" step="0.01" name="cost" defaultValue={product.cost} className="input-field" placeholder="0.00" />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium mb-1">SKU / Barcode</label>
                                            <div className="flex gap-2">
                                                <input type="text" name="sku" defaultValue={product.sku} className="input-field flex-1" placeholder="e.g. PRD-001" />
                                                <button type="button" onClick={handleScan} className="btn-secondary px-3" title="Scan Barcode">
                                                    <div className="icon-scan text-lg"></div>
                                                </button>
                                            </div>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium mb-1">Initial Stock</label>
                                            <input type="number" name="stock" defaultValue={product.stock} className="input-field" placeholder="0" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-6">
                                <div className="card space-y-4">
                                    <h3 className="font-semibold text-lg border-b border-[var(--border-color)] pb-3">Organization</h3>
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Category</label>
                                        <select name="category" defaultValue={product.category} className="input-field">
                                            {categories.map(cat => (
                                                <option key={cat.id} value={cat.name}>{cat.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium mb-1">Status</label>
                                        <select name="status" defaultValue={product.status || 'Active'} className="input-field">
                                            <option>Active</option>
                                            <option>Draft</option>
                                            <option>Archived</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="card">
                                    <div className="flex flex-col gap-3">
                                        <button type="submit" className="btn-primary w-full justify-center">Save Product</button>
                                        <button type="button" onClick={() => window.location.href='/products.html'} className="btn-secondary w-full justify-center">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    {isScanning && (
                        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
                            <div className="bg-[var(--bg-panel)] border border-[var(--border-color)] rounded-xl p-8 max-w-sm w-full text-center">
                                <div className="w-16 h-16 bg-[var(--primary)]/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                                    <div className="icon-scan text-3xl text-[var(--primary)]"></div>
                                </div>
                                <h2 className="text-xl font-bold mb-2">Scanning Barcode...</h2>
                                <p className="text-[var(--text-muted)]">Please hold the barcode in front of the scanner.</p>
                                <button type="button" className="mt-6 text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors text-sm" onClick={() => setIsScanning(false)}>
                                    Cancel
                                </button>
                            </div>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AddProductApp />);