function SettingsApp() {
    const [settings, setSettings] = React.useState(() => {
        const stored = localStorage.getItem('nexpos_settings');
        return stored ? JSON.parse(stored) : {
            storeName: 'NexPOS Main Store',
            currency: 'USD ($)',
            taxRate: 8
        };
    });
    const [saved, setSaved] = React.useState(false);

    const handleSave = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const rawTax = parseFloat(formData.get('taxRate'));
        const newSettings = {
            storeName: formData.get('storeName'),
            currency: formData.get('currency'),
            taxRate: isNaN(rawTax) ? 0 : rawTax
        };
        localStorage.setItem('nexpos_settings', JSON.stringify(newSettings));
        setSettings(newSettings);
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
    };

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/settings.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Settings" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-3xl mx-auto">
                        <div className="mb-6">
                            <h2 className="text-2xl font-bold">Store Settings</h2>
                            <p className="text-[var(--text-muted)] mt-1">Manage your store preferences and system configuration.</p>
                        </div>
                        <form onSubmit={handleSave} className="card space-y-6 relative">
                            {saved && (
                                <div className="absolute -top-14 left-1/2 -translate-x-1/2 bg-[var(--success)] text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2">
                                    <div className="icon-circle-check text-xl"></div>
                                    Settings saved successfully!
                                </div>
                            )}
                            <div>
                                <label className="block text-sm font-medium mb-2">Store Name</label>
                                <input type="text" name="storeName" className="input-field" defaultValue={settings.storeName} required />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium mb-2">Currency</label>
                                    <select name="currency" className="input-field" defaultValue={settings.currency}>
                                        <option>USD ($)</option>
                                        <option>EUR (€)</option>
                                        <option>GBP (£)</option>
                                        <option>DZD (د.ج)</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-2">Default Tax Rate (%)</label>
                                    <input type="number" name="taxRate" step="0.1" className="input-field" defaultValue={settings.taxRate} required />
                                </div>
                            </div>
                            <div className="pt-4 border-t border-[var(--border-color)] flex justify-end">
                                <button type="submit" className="btn-primary">
                                    <div className="icon-save"></div>
                                    Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<SettingsApp />);