# NexPOS System

## Overview
NexPOS is a cloud-based Point of Sale and Inventory Management system designed for small and medium businesses.

## Tech Stack
- Frontend: React 18, TailwindCSS
- Design: Dark/Purple premium business theme

## Structure
- `index.html`: Main Dashboard Overview
- `pos.html`: Point of Sale Interface
- `products.html`: Product list and management
- `add-product.html`: Form to create new products
- `categories.html`: Management for product categories
- `add-category.html`: Form to add new product categories
- `inventory.html`: Stock levels and tracking
- `customers.html`: Customer directory and history
- `add-customer.html`: Form to create new customers
- `invoices.html`: Display history of generated invoices
- `reports.html`: Analytics and data export
- `settings.html`: Store configuration
- `login.html`: Authentication entry point
- `components/`: Shared layout elements (Sidebar, Header)

## Maintenance
When modifying pages, always ensure navigation stays consistent and theme variables are utilized properly.