When the project structure or key features are significantly updated:
- rule 1: Always check if `trickle/notes/README.md` needs to be updated.
- rule 2: Document any new pages or important components added to the system.