function getStoreSettings() {
    const stored = localStorage.getItem('nexpos_settings');
    const defaultSettings = {
        storeName: 'NexPOS Main Store',
        currency: 'USD ($)',
        taxRate: 8
    };
    if (!stored) return defaultSettings;
    try {
        return JSON.parse(stored);
    } catch (e) {
        return defaultSettings;
    }
}

function getCurrencySymbol() {
    const currency = getStoreSettings().currency || 'USD ($)';
    if (currency.includes('(') && currency.includes(')')) {
        return currency.split('(')[1].split(')')[0];
    }
    return '$';
}

function formatCurrency(amount) {
    const symbol = getCurrencySymbol();
    const formatted = parseFloat(amount).toFixed(2);
    if (symbol === 'د.ج' || symbol === '€') {
        return `${formatted} ${symbol}`;
    }
    return `${symbol}${formatted}`;
}