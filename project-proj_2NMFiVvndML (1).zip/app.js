class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[var(--bg-base)]">
          <div className="text-center card">
            <h1 className="text-2xl font-bold text-[var(--danger)] mb-4">Something went wrong</h1>
            <p className="text-[var(--text-muted)] mb-4">We're sorry, but something unexpected happened.</p>
            <button onClick={() => window.location.reload()} className="btn-primary mx-auto">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function DashboardStats() {
    const stats = [
        { title: 'Total Sales', value: formatCurrency(12426).replace('.00', ''), trend: '+14%', isPositive: true, icon: 'dollar-sign' },
        { title: 'Total Orders', value: '384', trend: '+8%', isPositive: true, icon: 'shopping-cart' },
        { title: 'Total Products', value: '1,240', trend: '-2%', isPositive: false, icon: 'package' },
        { title: 'Total Customers', value: '8,432', trend: '+12%', isPositive: true, icon: 'users' },
    ];

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            {stats.map((stat, i) => (
                <div key={i} className="card flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                        <div className="w-10 h-10 rounded-lg bg-[var(--bg-panel-hover)] flex items-center justify-center">
                            <div className={`icon-${stat.icon} text-[var(--primary)] text-xl`}></div>
                        </div>
                        <span className={`text-sm font-medium ${stat.isPositive ? 'text-[var(--success)]' : 'text-[var(--danger)]'}`}>
                            {stat.trend}
                        </span>
                    </div>
                    <div>
                        <h3 className="text-[var(--text-muted)] text-sm font-medium mb-1">{stat.title}</h3>
                        <p className="text-2xl font-bold text-[var(--text-main)]">{stat.value}</p>
                    </div>
                </div>
            ))}
        </div>
    );
}

function DashboardChart() {
    const canvasRef = React.useRef(null);
    const chartRef = React.useRef(null);

    React.useEffect(() => {
        if (!canvasRef.current) return;

        if (chartRef.current) {
            chartRef.current.destroy();
        }

        const ctx = canvasRef.current.getContext('2d');
        chartRef.current = new ChartJS(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: `Sales (${getCurrencySymbol()})`,
                    data: [1200, 1900, 1500, 2200, 1800, 2800, 2400],
                    borderColor: '#7c3aed',
                    backgroundColor: 'rgba(124, 58, 237, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#334155' },
                        ticks: { color: '#94a3b8' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#94a3b8' }
                    }
                }
            }
        });

        return () => {
            if (chartRef.current) chartRef.current.destroy();
        };
    }, []);

    return (
        <div className="card h-96 flex flex-col">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">Revenue Overview</h2>
                <select className="bg-[var(--bg-base)] border border-[var(--border-color)] rounded-lg px-3 py-1.5 text-sm outline-none">
                    <option>This Week</option>
                    <option>This Month</option>
                    <option>This Year</option>
                </select>
            </div>
            <div className="flex-1 relative">
                <canvas ref={canvasRef}></canvas>
            </div>
        </div>
    );
}

function App() {
    try {
        const currentPath = window.location.pathname;

        return (
            <div className="flex h-screen bg-[var(--bg-base)]" data-name="app" data-file="app.js">
                <Sidebar currentPath={currentPath} />
                <div className="flex-1 flex flex-col overflow-hidden">
                    <Header title="Dashboard Overview" />
                    <main className="flex-1 overflow-y-auto p-6">
                        <div className="max-w-7xl mx-auto">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <h2 className="text-2xl font-bold text-[var(--text-main)]">Welcome back, John!</h2>
                                    <p className="text-[var(--text-muted)] mt-1">Here is what's happening with your store today.</p>
                                </div>
                                <button className="btn-primary" onClick={() => window.location.href='/add-product.html'}>
                                    <div className="icon-plus text-lg"></div>
                                    Add Product
                                </button>
                            </div>
                            
                            <DashboardStats />
                            
                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                                <div className="lg:col-span-2">
                                    <DashboardChart />
                                </div>
                                <div className="card">
                                    <h2 className="text-lg font-semibold mb-4">Low Stock Alerts</h2>
                                    <div className="space-y-4">
                                        {[
                                            { name: 'Wireless Headphones', stock: 5, status: 'warning' },
                                            { name: 'USB-C Cable', stock: 2, status: 'danger' },
                                            { name: 'Phone Case', stock: 0, status: 'danger' },
                                            { name: 'Screen Protector', stock: 8, status: 'warning' },
                                        ].map((item, i) => (
                                            <div key={i} className="flex justify-between items-center p-3 rounded-lg bg-[var(--bg-base)] border border-[var(--border-color)]">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 bg-[var(--bg-panel-hover)] rounded-lg flex items-center justify-center">
                                                        <div className="icon-package text-[var(--text-muted)]"></div>
                                                    </div>
                                                    <div>
                                                        <p className="font-medium text-sm text-[var(--text-main)]">{item.name}</p>
                                                        <p className={`text-xs ${item.status === 'danger' ? 'text-[var(--danger)]' : 'text-[var(--warning)]'}`}>
                                                            {item.stock} in stock
                                                        </p>
                                                    </div>
                                                </div>
                                                <button className="text-[var(--primary)] text-sm hover:underline">Restock</button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        );
    } catch (error) {
        console.error('App component error:', error);
        return null;
    }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);