function Header({ title }) {
    return (
        <header className="h-16 bg-[var(--bg-panel)] border-b border-[var(--border-color)] flex items-center justify-between px-6 sticky top-0 z-10" data-name="header" data-file="components/Header.js">
            <div className="flex items-center gap-4">
                <button className="md:hidden text-[var(--text-muted)] hover:text-[var(--text-main)]">
                    <div className="icon-menu text-2xl"></div>
                </button>
                <h1 className="text-xl font-bold text-[var(--text-main)]">{title}</h1>
            </div>

            <div className="flex items-center gap-4">
                <div className="relative hidden sm:block">
                    <div className="icon-search absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"></div>
                    <input 
                        type="text" 
                        placeholder="Search anything..." 
                        className="bg-[var(--bg-base)] border border-[var(--border-color)] rounded-lg pl-10 pr-4 py-2 text-sm text-[var(--text-main)] focus:outline-none focus:border-[var(--primary)] w-64"
                    />
                </div>
                
                <button className="relative text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors p-2 rounded-lg hover:bg-[var(--bg-panel-hover)]">
                    <div className="icon-bell text-xl"></div>
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[var(--danger)] rounded-full"></span>
                </button>
            </div>
        </header>
    );
}