function Sidebar({ currentPath }) {
    const navItems = [
        { name: 'Dashboard', icon: 'chart-pie', path: '/index.html' },
        { name: 'Point of Sale', icon: 'calculator', path: '/pos.html' },
        { name: 'Products', icon: 'package', path: '/products.html' },
        { name: 'Categories', icon: 'tags', path: '/categories.html' },
        { name: 'Inventory', icon: 'boxes', path: '/inventory.html' },
        { name: 'Customers', icon: 'users', path: '/customers.html' },
        { name: 'Invoices', icon: 'receipt', path: '/invoices.html' },
        { name: 'Reports', icon: 'chart-bar', path: '/reports.html' },
        { name: 'Settings', icon: 'settings', path: '/settings.html' },
    ];

    const handleNavigation = (path) => {
        if (path !== '#') {
            window.location.href = path;
        }
    };

    return (
        <aside className="w-64 bg-[var(--bg-panel)] border-r border-[var(--border-color)] h-screen flex flex-col hidden md:flex" data-name="sidebar" data-file="components/Sidebar.js">
            <div className="h-16 flex items-center px-6 border-b border-[var(--border-color)]">
                <div className="flex items-center gap-2 text-2xl font-bold text-[var(--text-main)]">
                    <div className="icon-hexagon text-[var(--primary)]"></div>
                    NexPOS
                </div>
            </div>
            
            <nav className="flex-1 overflow-y-auto py-4">
                <ul className="space-y-1 px-3">
                    {navItems.map((item) => {
                        const isActive = currentPath.includes(item.path) || (currentPath === '/' && item.path === '/index.html');
                        return (
                            <li key={item.name}>
                                <button
                                    onClick={() => handleNavigation(item.path)}
                                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                                        isActive 
                                        ? 'bg-[var(--primary)] text-white' 
                                        : 'text-[var(--text-muted)] hover:bg-[var(--bg-panel-hover)] hover:text-[var(--text-main)]'
                                    }`}
                                >
                                    <div className={`icon-${item.icon} text-xl`}></div>
                                    <span className="font-medium">{item.name}</span>
                                </button>
                            </li>
                        );
                    })}
                </ul>
            </nav>

            <div className="p-4 border-t border-[var(--border-color)]">
                <div className="flex items-center justify-between px-3 py-2 group hover:bg-[var(--bg-panel-hover)] rounded-lg transition-colors cursor-pointer" onClick={() => window.location.href='/login.html'}>
                    <div className="flex items-center gap-3">
                        <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" alt="Admin" className="w-10 h-10 rounded-full" />
                        <div>
                            <p className="text-sm font-medium text-[var(--text-main)] group-hover:text-white transition-colors">John Admin</p>
                            <p className="text-xs text-[var(--text-muted)]">Store Manager</p>
                        </div>
                    </div>
                    <button className="text-[var(--text-muted)] hover:text-[var(--danger)] transition-colors p-2 rounded-md" title="Sign Out">
                        <div className="icon-log-out"></div>
                    </button>
                </div>
            </div>
        </aside>
    );
}