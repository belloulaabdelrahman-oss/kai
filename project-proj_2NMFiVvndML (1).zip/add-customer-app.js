function AddCustomerApp() {
    const handleSave = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        
        const newCustomer = {
            id: Date.now(),
            name: formData.get('name'),
            email: formData.get('email') || 'N/A',
            phone: formData.get('phone') || 'N/A',
            totalSpent: 0.00,
            lastVisit: new Date().toISOString().split('T')[0]
        };

        const stored = localStorage.getItem('nexpos_customers');
        const defaultCustomers = [
            { id: 1, name: 'Alice Smith', email: 'alice@example.com', phone: '+1 234-567-8900', totalSpent: 1250.00, lastVisit: '2026-06-15' },
            { id: 2, name: 'Bob Jones', email: 'bob@example.com', phone: '+1 987-654-3210', totalSpent: 450.50, lastVisit: '2026-06-18' },
        ];
        const customers = stored ? JSON.parse(stored) : defaultCustomers;
        
        customers.unshift(newCustomer);
        localStorage.setItem('nexpos_customers', JSON.stringify(customers));
        window.location.href = '/customers.html';
    };

    return (
        <div className="flex h-screen bg-[var(--bg-base)]">
            <Sidebar currentPath="/customers.html" />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title="Add New Customer" />
                <main className="flex-1 overflow-y-auto p-6">
                    <div className="max-w-2xl mx-auto">
                        <div className="flex items-center gap-4 mb-6">
                            <button onClick={() => window.location.href='/customers.html'} className="text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors">
                                <div className="icon-arrow-left text-2xl"></div>
                            </button>
                            <h2 className="text-2xl font-bold">Create Customer</h2>
                        </div>
                        
                        <form onSubmit={handleSave} className="space-y-6">
                            <div className="card space-y-4">
                                <h3 className="font-semibold text-lg border-b border-[var(--border-color)] pb-3">Customer Details</h3>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Full Name</label>
                                    <input type="text" name="name" className="input-field" placeholder="e.g. John Doe" required />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Email Address</label>
                                    <input type="email" name="email" className="input-field" placeholder="john@example.com" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium mb-1">Phone Number</label>
                                    <input type="tel" name="phone" className="input-field" placeholder="+1 234-567-8900" />
                                </div>
                            </div>

                            <div className="flex gap-3">
                                <button type="submit" className="btn-primary flex-1 justify-center">Save Customer</button>
                                <button type="button" onClick={() => window.location.href='/customers.html'} className="btn-secondary flex-1 justify-center">Cancel</button>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<AddCustomerApp />);